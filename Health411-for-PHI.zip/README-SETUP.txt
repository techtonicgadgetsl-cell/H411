HEALTH 411 - HOW TO SET UP FOR YOUR OWN AREA
=============================================

Files in this folder
  index.html        main report entry page (open this every day)
  disease-map.html  disease location map (button inside index.html)
  setup.html        one-time setup wizard
  form-page1.jpg / form-page2.jpg   the H411 form pictures used for printing
  config.js + area-geo.js           YOUR area settings (made by setup.html in step 3)

ONE-TIME SETUP (about 15 minutes)
  1. Make your own Firebase database
       - console.firebase.google.com -> Add project
       - Build -> Realtime Database -> Create database
       - Project settings -> Your apps -> Web (</>) -> copy the firebaseConfig block
     (Your own project = your patient data stays separate from other PHIs.)
  2. Get your area GeoJSON (GN divisions as polygons) from your office / GIS unit.
  3. Open setup.html in Chrome and fill in the 5 steps:
       area name -> paste firebaseConfig -> choose the GeoJSON -> tick GN divisions
       and type the PHM area of each -> press "Save config.js" and "Save area-geo.js".
  4. Put config.js and area-geo.js in the SAME folder as index.html.
  5. Open index.html. The GN list, PHM area and map are now for your area.

IMPORTANT
  - Do NOT copy someone else's config.js (it holds their database key).
  - Patient data is sensitive. Do not share your page link publicly, and set
    your Firebase database rules so that not everybody can read it.
  - To change area later, run setup.html again and replace the two files.
  - Gemini API key (for photo reading) is typed inside the app, per user.
