/* Health 411 - daily "waiting for confirmation" reminder.
   Reads the reports from your Firebase database, finds the ones that have no confirmed disease / date,
   and sends the list to Telegram and/or e-mail. Runs on GitHub Actions (see .github/workflows/daily-pending.yml).
   No patient data is ever printed to the (public) Action log. */
import fs from 'node:fs';

const env = process.env;
const yes = v => /^(1|true|yes|on)$/i.test(String(v || '').trim());
const DAYS = Number(env.CONFIRM_ALERT_DAYS || 3);        // red / overdue after this many days
const SHOW_NAME = yes(env.SHOW_NAME);                      // default: names are NOT sent
const SHOW_PHONE = yes(env.SHOW_PHONE);                    // default: phone numbers are NOT sent
const SEND_WHEN_EMPTY = yes(env.SEND_WHEN_EMPTY);          // default: stay quiet when nothing is pending
const DRY = yes(env.DRY_RUN);                              // test only: print instead of sending
const TG_BASE = env.TELEGRAM_API_BASE || 'https://api.telegram.org';

function areaName() {
  if (env.AREA_NAME) return env.AREA_NAME;
  try { const m = fs.readFileSync(new URL('../config.js', import.meta.url), 'utf8').match(/"areaName"\s*:\s*"([^"]+)"/); if (m) return m[1]; } catch { /* no config.js */ }
  return 'Health 411';
}

async function loadRecords() {
  if (env.MOCK_RECORDS) return Object.entries(JSON.parse(fs.readFileSync(env.MOCK_RECORDS, 'utf8'))).map(([id, v]) => ({ ...v, id }));
  const admin = (await import('firebase-admin')).default;
  admin.initializeApp({ credential: admin.credential.cert(JSON.parse(env.FIREBASE_SERVICE_ACCOUNT)), databaseURL: env.FIREBASE_DATABASE_URL });
  const val = (await admin.database().ref('health_reports').once('value')).val() || {};
  await admin.app().delete();
  return Object.entries(val).map(([id, r]) => ({ ...r, id }));
}

const todayLK = () => new Date().toLocaleDateString('en-CA', { timeZone: 'Asia/Colombo' });   // yyyy-mm-dd, Sri Lanka time
function daysSince(d) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(d || '')) return null;
  const [y1, m1, d1] = d.split('-').map(Number), [y2, m2, d2] = todayLK().split('-').map(Number);
  return Math.round((Date.UTC(y2, m2 - 1, d2) - Date.UTC(y1, m1 - 1, d1)) / 86400000);
}
function pending(records) {
  return records
    .filter(r => !((r.inDiseaseConfirmed || '').trim() || (r.inDateConfirmed || '').trim()))      // same rule as the portal
    .map(r => { const days = daysSince(r.inDateNotified); return { r, days, overdue: days !== null && days >= DAYS }; })
    .sort((a, b) => (b.days === null ? -1 : b.days) - (a.days === null ? -1 : a.days));           // longest waiting first
}
function line(x) {
  const p = [`${x.overdue ? '⏰' : '•'} ${x.days === null ? '-' : x.days + 'd'}`, x.r.inPhiRefNo || 'No Ref'];
  if (SHOW_NAME) p.push(x.r.inPatientName || 'Unnamed');
  p.push(x.r.inDiseaseNotified || 'N/A', 'notified ' + (x.r.inDateNotified || '-'));
  if (x.r.inGNArea) p.push('GN ' + x.r.inGNArea);
  if (SHOW_PHONE && x.r.inPatientPhone) p.push(x.r.inPatientPhone);
  return p.join(' | ');
}
function build(list, area) {
  const od = list.filter(x => x.overdue), wait = list.filter(x => !x.overdue);
  const title = `⏳ ${area}: ${list.length} report(s) waiting for confirmation` + (od.length ? ` — ${od.length} overdue (${DAYS}+ days)` : '');
  const lines = [title, ''];
  if (od.length) lines.push(`OVERDUE (${DAYS}+ days)`, ...od.map(line), '');
  if (wait.length) lines.push(`Waiting (under ${DAYS} days)`, ...wait.map(line), '');
  lines.push('Open the portal → ⏳ Pending Confirmation to update them.');
  return { title, lines, od, wait };
}
function chunks(lines, max = 3500) {
  const out = []; let cur = '';
  for (const l of lines) { if ((cur + l + '\n').length > max && cur) { out.push(cur.trimEnd()); cur = ''; } cur += l + '\n'; }
  if (cur.trim()) out.push(cur.trimEnd());
  return out;
}
const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

async function sendTelegram(parts) {
  for (const text of parts) {
    const res = await fetch(`${TG_BASE}/bot${env.TELEGRAM_BOT_TOKEN}/sendMessage`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ chat_id: env.TELEGRAM_CHAT_ID, text }) });
    if (!res.ok) throw new Error('Telegram error HTTP ' + res.status);
  }
}
async function sendEmail(b) {
  const nodemailer = (await import('nodemailer')).default;
  const port = Number(env.SMTP_PORT || 465);
  const t = nodemailer.createTransport({ host: env.SMTP_HOST, port, secure: port === 465, auth: { user: env.SMTP_USER, pass: env.SMTP_PASS } });
  const rows = [...b.od, ...b.wait].map(x => `<tr style="${x.overdue ? 'background:#fef2f2;color:#b91c1c;' : ''}"><td>${x.overdue ? '⏰ ' : ''}${x.days === null ? '-' : x.days + ' d'}</td><td>${esc(x.r.inPhiRefNo || 'No Ref')}</td>${SHOW_NAME ? `<td>${esc(x.r.inPatientName || '')}</td>` : ''}<td>${esc(x.r.inDiseaseNotified || '')}</td><td>${esc(x.r.inDateNotified || '-')}</td><td>${esc(x.r.inGNArea || '')}</td>${SHOW_PHONE ? `<td>${esc(x.r.inPatientPhone || '')}</td>` : ''}</tr>`).join('');
  const head = ['Waiting', 'Ref No', SHOW_NAME && 'Patient', 'Disease (notified)', 'Date notified', 'GN', SHOW_PHONE && 'Phone'].filter(Boolean).map(h => `<th style="text-align:left;border-bottom:2px solid #334155;padding:4px 8px">${h}</th>`).join('');
  await t.sendMail({ from: env.SMTP_FROM || env.SMTP_USER, to: env.MAIL_TO, subject: b.title, text: b.lines.join('\n'),
    html: `<h3>${esc(b.title)}</h3><table style="border-collapse:collapse;font-family:Arial;font-size:14px"><thead><tr>${head}</tr></thead><tbody>${rows}</tbody></table><p>Open the portal → ⏳ Pending Confirmation to update them.</p>` });
}

const records = await loadRecords();
const list = pending(records), area = areaName(), b = build(list, area);
console.log(`Records: ${records.length} | pending: ${list.length} | overdue: ${b.od.length}`);        // counts only, never patient data
if (!list.length && !SEND_WHEN_EMPTY) { console.log('Nothing pending - no message sent.'); process.exit(0); }
if (!list.length) { b.lines = [`✔ ${area}: nothing waiting for confirmation.`]; b.title = b.lines[0]; b.od = []; b.wait = []; }

const jobs = [];
if (env.TELEGRAM_BOT_TOKEN && env.TELEGRAM_CHAT_ID) jobs.push(['Telegram', () => sendTelegram(chunks(b.lines))]);
if (env.SMTP_HOST && env.SMTP_USER && env.SMTP_PASS && env.MAIL_TO) jobs.push(['Email', () => sendEmail(b)]);
if (!jobs.length) { console.error('No Telegram or e-mail settings found (see reminders/SETUP-REMINDER.txt).'); process.exit(1); }
if (DRY) { console.log('--- DRY RUN: would send ---\n' + b.lines.join('\n') + '\n--- via: ' + jobs.map(j => j[0]).join(', ')); process.exit(0); }

let failed = 0;
for (const [name, fn] of jobs) { try { await fn(); console.log(name + ': sent'); } catch (e) { failed++; console.error(name + ': FAILED - ' + e.message); } }
process.exit(failed ? 1 : 0);
